import type { ScienceF3ChapterSource } from "../chapter-data";

const bi = (bm: string, dlp: string) => ({ bm, dlp });
const lesson = (id: string, bm: string, dlp: string, bodyBM: string, bodyDLP: string) => ({
  id, term: bi(bm, dlp), statement: bi(bodyBM, bodyDLP),
});

// Textbook mineral names describe the constituents at Form 3 level.
// Pyrite is FeS₂ (iron disulphide); retain the textbook's sulphide label
// without introducing the incorrect formula FeS.
export const chapter4Minerals = [
  { name: bi("Hematit", "Hematite"), compound: bi("Ferum(III) oksida", "Iron(III) oxide"), elements: bi("Ferum + oksigen", "Iron + oxygen") },
  { name: bi("Kasiterit", "Cassiterite"), compound: bi("Timah(IV) oksida", "Tin(IV) oxide"), elements: bi("Timah + oksigen", "Tin + oxygen") },
  { name: bi("Kuarza", "Quartz"), compound: bi("Silikon dioksida", "Silicon dioxide"), elements: bi("Silikon + oksigen", "Silicon + oxygen") },
  { name: bi("Bauksit", "Bauxite"), compound: bi("Aluminium oksida", "Aluminium oxide"), elements: bi("Aluminium + oksigen", "Aluminium + oxygen") },
  { name: bi("Galena", "Galena"), compound: bi("Plumbum(II) sulfida", "Lead(II) sulphide"), elements: bi("Plumbum + sulfur", "Lead + sulphur") },
  { name: bi("Pirit", "Pyrite"), compound: bi("Ferum(II) sulfida", "Iron(II) sulphide"), elements: bi("Ferum + sulfur", "Iron + sulphur") },
  { name: bi("Kalsit", "Calcite"), compound: bi("Kalsium karbonat", "Calcium carbonate"), elements: bi("Kalsium + karbon + oksigen", "Calcium + carbon + oxygen") },
];

export const chapter4Lessons = {
  minerals: [
    lesson("mineral", "Mineral", "Mineral", "Mineral ialah unsur atau sebatian pepejal semula jadi dengan struktur hablur dan komposisi kimia yang tertentu.", "A mineral is a naturally occurring solid element or compound with a definite crystalline structure and chemical composition."),
    lesson("elements", "Mineral unsur", "Elemental minerals", "Emas, perak dan intan ialah mineral unsur. Intan terdiri daripada unsur karbon.", "Gold, silver and diamond are elemental minerals. Diamond consists of the element carbon."),
    lesson("compound", "Sebatian semula jadi", "Natural compounds", "Sebatian terdiri daripada dua atau lebih unsur yang bergabung secara kimia. Nama sebatian membantu kita mengenal pasti unsur gabungannya.", "A compound consists of two or more elements chemically combined. Its name helps us identify its constituent elements."),
    ...chapter4Minerals.map((m, i) => lesson(`mineral-${i}`, m.name.bm, m.name.dlp, `${m.compound.bm}; unsur: ${m.elements.bm.toLowerCase()}.`, `${m.compound.dlp}; elements: ${m.elements.dlp.toLowerCase()}.`)),
    lesson("carbonate-acid", "Kalsium karbonat dengan asid", "Calcium carbonate with acid", "Kalsium karbonat + asid hidroklorik → kalsium klorida + karbon dioksida + air. Gelembung gas terhasil; karbon dioksida mengeruhkan air kapur.", "Calcium carbonate + hydrochloric acid → calcium chloride + carbon dioxide + water. Gas bubbles form; carbon dioxide turns limewater cloudy."),
    lesson("carbonate-heat", "Pemanasan kalsium karbonat", "Heating calcium carbonate", "Kalsium karbonat → kalsium oksida + karbon dioksida. Apabila dipanaskan kuat, gas yang terhasil mengeruhkan air kapur. Berdasarkan hasil tindak balas, kalsium karbonat mengandungi kalsium, karbon dan oksigen.", "Calcium carbonate → calcium oxide + carbon dioxide. Strong heating releases gas that turns limewater cloudy. From the reaction products, calcium carbonate contains calcium, carbon and oxygen."),
    lesson("calcium-oxide-use", "Sifat → kegunaan: kalsium oksida", "Property → use: calcium oxide", "Bersifat bes → meneutralkan asid → digunakan untuk meneutralkan tanah berasid.", "Basic → neutralises acids → used to neutralise acidic soil."),
    lesson("silica-use", "Sifat → kegunaan: silikon dioksida", "Property → use: silicon dioxide", "Takat lebur tinggi → tahan suhu tinggi → bahan untuk membuat kaca dan radas kaca makmal.", "High melting point → withstands high temperatures → a material for making glass and laboratory glassware."),
    lesson("carbonate-use", "Sifat → kegunaan: kalsium karbonat", "Property → use: calcium carbonate", "Batu kapur ialah bahan pepejal keras yang mengandungi kalsium karbonat → sesuai sebagai batu binaan. Kalsium karbonat terurai apabila dipanaskan → membekalkan kalsium oksida untuk pembuatan simen.", "Limestone is a hard solid containing calcium carbonate → useful as building stone. Calcium carbonate decomposes when heated → supplies calcium oxide for cement manufacture."),
  ],
  reactivity: [
    lesson("oxygen-rule", "Kereaktifan terhadap oksigen", "Reactivity towards oxygen", "Semakin reaktif logam, semakin cergas tindak balasnya dengan oksigen. Logam + oksigen → oksida logam. Bandingkan serbuk logam dalam keadaan penyiasatan yang sama.", "The more reactive a metal, the more vigorously it reacts with oxygen. Metal + oxygen → metal oxide. Compare metal powders under the same investigation conditions."),
    lesson("oxygen-mg", "Magnesium dengan oksigen", "Magnesium with oxygen", "Terbakar amat cepat dengan nyalaan terang. Magnesium + oksigen → magnesium oksida.", "Burns very quickly with a bright flame. Magnesium + oxygen → magnesium oxide."),
    lesson("oxygen-al", "Aluminium dengan oksigen", "Aluminium with oxygen", "Terbakar cepat dengan nyalaan terang. Aluminium + oksigen → aluminium oksida.", "Burns quickly with a bright flame. Aluminium + oxygen → aluminium oxide."),
    lesson("oxygen-zn", "Zink dengan oksigen", "Zinc with oxygen", "Terbakar lebih perlahan. Zink + oksigen → zink oksida.", "Burns more slowly. Zinc + oxygen → zinc oxide."),
    lesson("oxygen-fe", "Ferum dengan oksigen", "Iron with oxygen", "Berbara terang. Ferum + oksigen → ferum oksida.", "Glows brightly. Iron + oxygen → iron oxide."),
    lesson("oxygen-pb", "Plumbum dengan oksigen", "Lead with oxygen", "Berbara malap. Plumbum + oksigen → plumbum oksida.", "Glows dimly. Lead + oxygen → lead oxide."),
    lesson("oxygen-order", "Pemerhatian → susunan", "Observation → order", "Nyalaan lebih cepat dan terang menunjukkan tindak balas lebih cergas. Susunan menurun bagi lima logam: Mg > Al > Zn > Fe > Pb.", "Faster, brighter burning indicates a more vigorous reaction. Decreasing order for the five metals: Mg > Al > Zn > Fe > Pb."),
    lesson("series", "Siri kereaktifan lengkap", "Full reactivity series", "K > Na > Ca > Mg > Al > C > Zn > H > Fe > Sn > Pb > Cu > Hg > Ag > Au, daripada paling reaktif kepada paling kurang reaktif.", "K > Na > Ca > Mg > Al > C > Zn > H > Fe > Sn > Pb > Cu > Hg > Ag > Au, from most to least reactive."),
    lesson("non-metals", "Karbon dan hidrogen", "Carbon and hydrogen", "Kedua-duanya bukan logam. Keupayaan menyingkirkan oksigen daripada oksida logam membolehkan kereaktifannya dibandingkan dengan logam.", "Both are non-metals. Their ability to remove oxygen from metal oxides allows their reactivity to be compared with metals."),
    lesson("carbon-al", "Karbon + aluminium oksida", "Carbon + aluminium oxide", "Tiada tindak balas: karbon tidak dapat menurunkan aluminium oksida kerana aluminium lebih reaktif daripada karbon.", "No reaction: carbon cannot reduce aluminium oxide because aluminium is more reactive than carbon."),
    lesson("carbon-zn", "Karbon + zink oksida", "Carbon + zinc oxide", "Tindak balas berlaku: zink oksida + karbon → zink + karbon dioksida. Karbon lebih reaktif daripada zink.", "A reaction occurs: zinc oxide + carbon → zinc + carbon dioxide. Carbon is more reactive than zinc."),
    lesson("carbon-pb", "Karbon + plumbum(II) oksida", "Carbon + lead(II) oxide", "Tindak balas berlaku: plumbum(II) oksida + karbon → plumbum + karbon dioksida. Karbon lebih reaktif daripada plumbum.", "A reaction occurs: lead(II) oxide + carbon → lead + carbon dioxide. Carbon is more reactive than lead."),
    lesson("carbon-position", "Kedudukan karbon", "Position of carbon", "Aluminium lebih reaktif daripada karbon; karbon lebih reaktif daripada zink dan plumbum. Maka karbon berada antara aluminium dan zink: Al > C > Zn.", "Aluminium is more reactive than carbon; carbon is more reactive than zinc and lead. Carbon therefore lies between aluminium and zinc: Al > C > Zn."),
    lesson("hydrogen", "Bukti kedudukan hidrogen", "Evidence for hydrogen's position", "Hidrogen tidak dapat menurunkan zink oksida tetapi dapat menurunkan oksida ferum, plumbum dan kuprum. Maka hidrogen berada antara zink dan ferum: Zn > H > Fe.", "Hydrogen cannot reduce zinc oxide but can reduce iron, lead and copper oxides. Hydrogen therefore lies between zinc and iron: Zn > H > Fe."),
    lesson("hydrogen-rule", "Penurunan oleh hidrogen", "Reduction by hydrogen", "Hidrogen + oksida logam → logam + air. Jika hidrogen menyingkirkan oksigen, hidrogen lebih reaktif daripada logam itu; jika tidak, logam itu lebih reaktif daripada hidrogen.", "Hydrogen + metal oxide → metal + water. If hydrogen removes the oxygen, hydrogen is more reactive than the metal; if it cannot, the metal is more reactive than hydrogen."),
  ],
  extraction: [
    lesson("extraction", "Pengekstrakan logam", "Metal extraction", "Proses mendapatkan logam daripada bijihnya. Kereaktifan logam menentukan kaedah pengekstrakan yang sesuai.", "The process of obtaining a metal from its ore. Metal reactivity determines a suitable extraction method."),
    lesson("electrolysis", "Di atas karbon: K, Na, Ca, Mg, Al", "Above carbon: K, Na, Ca, Mg, Al", "Kalium, natrium, kalsium, magnesium dan aluminium → elektrolisis sebatian lebur kerana karbon tidak dapat menurunkan oksidanya.", "Potassium, sodium, calcium, magnesium and aluminium → electrolysis of molten compounds because carbon cannot reduce their oxides."),
    lesson("carbon-extraction", "Di bawah karbon: Zn, Fe, Sn, Pb", "Below carbon: Zn, Fe, Sn, Pb", "Zink, ferum, timah dan plumbum → penurunan oksida logam oleh karbon yang lebih reaktif.", "Zinc, iron, tin and lead → reduction of metal oxides by the more reactive carbon."),
    lesson("direct-heat", "Kuprum dan raksa: Cu, Hg", "Copper and mercury: Cu, Hg", "Diekstrak melalui pemanasan terus sebatian logamnya.", "Extracted by direct heating of their metallic compounds."),
    lesson("native", "Perak dan emas: Ag, Au", "Silver and gold: Ag, Au", "Sangat kurang reaktif dan boleh wujud sebagai unsur dalam kerak Bumi.", "Very unreactive and can occur as elements in Earth's crust."),
    lesson("furnace-inputs", "Bahan relau bagas", "Blast-furnace inputs", "Bijih ferum pekat (oksida ferum), kok dan batu kapur masuk dari atas. Udara panas ditiup masuk dari bawah.", "Concentrated iron ore (iron oxide), coke and limestone enter from above. Hot air is blown in from below."),
    lesson("coke", "Pembakaran kok", "Burning coke", "Karbon + oksigen → karbon dioksida. Pembakaran kok membebaskan haba untuk memanaskan relau.", "Carbon + oxygen → carbon dioxide. Burning coke releases heat to heat the furnace."),
    lesson("co", "Pembentukan karbon monoksida", "Formation of carbon monoxide", "Karbon dioksida + karbon → karbon monoksida. Karbon monoksida bertindak sebagai agen penurunan.", "Carbon dioxide + carbon → carbon monoxide. Carbon monoxide acts as a reducing agent."),
    lesson("reduction", "Penurunan oksida ferum", "Reduction of iron oxide", "Penurunan ialah penyingkiran oksigen daripada oksida logam. Ferum(III) oksida + karbon monoksida → ferum + karbon dioksida.", "Reduction is the removal of oxygen from a metal oxide. Iron(III) oxide + carbon monoxide → iron + carbon dioxide."),
    lesson("limestone", "Penguraian batu kapur", "Decomposition of limestone", "Kalsium karbonat → kalsium oksida + karbon dioksida. Kalsium oksida membantu menyingkirkan bendasing pasir.", "Calcium carbonate → calcium oxide + carbon dioxide. Calcium oxide helps remove sand impurities."),
    lesson("slag", "Pembentukan sanga", "Slag formation", "Kalsium oksida + silikon dioksida → kalsium silikat. Kalsium silikat ialah sanga.", "Calcium oxide + silicon dioxide → calcium silicate. Calcium silicate is slag."),
    lesson("separation", "Pemisahan ferum dan sanga", "Separating iron and slag", "Sanga kurang tumpat daripada ferum lebur lalu terapung di atasnya. Kedua-duanya disadap berasingan. Ferum lebur yang memejal membentuk besi tuangan.", "Slag is less dense than molten iron, so it floats above it. They are tapped separately. The molten iron solidifies as cast iron."),
    lesson("tin", "Timah di Malaysia", "Tin in Malaysia", "Kasiterit ialah bijih timah yang mengandungi timah(IV) oksida. Timah berada di bawah karbon, maka oksidanya boleh diturunkan oleh karbon.", "Cassiterite is tin ore containing tin(IV) oxide. Tin is below carbon, so its oxide can be reduced by carbon."),
    lesson("tin-reduction", "Mendapatkan timah", "Obtaining tin", "Timah(IV) oksida + karbon → timah + karbon dioksida.", "Tin(IV) oxide + carbon → tin + carbon dioxide."),
    lesson("tin-oxygen", "Timah dengan oksigen", "Tin with oxygen", "Timah + oksigen → timah(IV) oksida. Tindak balas ini menambahkan oksigen kepada timah; penurunan menyingkirkannya daripada oksida.", "Tin + oxygen → tin(IV) oxide. This reaction adds oxygen to tin; reduction removes it from the oxide."),
    lesson("mining-air", "Udara: masalah → kesan → idea", "Air: problem → effect → idea", "Pembakaran bahan api dan gas relau bagas mencemarkan udara → menjejaskan pernafasan → tapis atau rawat gas sebelum dilepaskan dan kawal pelepasan.", "Fuel burning and blast-furnace gases pollute air → harm breathing → filter or treat gases before release and control emissions."),
    lesson("mining-water", "Air: masalah → kesan → idea", "Water: problem → effect → idea", "Air pencucian bijih mencemarkan sungai → menjejaskan hidupan akuatik → rawat air sisa sebelum dilepaskan.", "Ore-cleaning wastewater pollutes rivers → harms aquatic life → treat wastewater before discharge."),
    lesson("mining-soil", "Tanih: masalah → kesan → idea", "Soil: problem → effect → idea", "Tanah terdedah mengalami hakisan → sungai menjadi cetek dan cerun tidak stabil → pulihkan kawasan, tanam semula pokok dan sediakan saliran yang sesuai.", "Exposed soil erodes → silts up rivers and destabilises slopes → rehabilitate land, replant trees and provide proper drainage."),
    lesson("mining-habitat", "Habitat: masalah → kesan → idea", "Habitat: problem → effect → idea", "Pembinaan lombong memusnahkan habitat → hidupan kehilangan tempat tinggal → hadkan zon perlombongan dan pulihkan tanah bekas lombong.", "Mine construction destroys habitats → organisms lose their homes → limit mining zones and rehabilitate mined land."),
    lesson("mining-noise", "Bunyi: masalah → kesan → idea", "Noise: problem → effect → idea", "Jentera menghasilkan pencemaran bunyi → mengganggu penduduk dan hidupan → kawal bunyi jentera, pasang penghadang dan pilih lokasi yang sesuai.", "Machinery causes noise pollution → disturbs residents and wildlife → control machinery noise, install barriers and choose suitable locations."),
    lesson("mining-energy", "Tenaga: masalah → kesan → idea", "Energy: problem → effect → idea", "Penggunaan elektrik tinggi → meningkatkan permintaan tenaga dan sumber bahan api → gunakan teknologi cekap tenaga dan tenaga secara bertanggungjawab. Cadangkan juga idea lain yang sesuai.", "High electricity use → increases demand for energy and fuel resources → use efficient technology and energy responsibly. Suggest other suitable ideas too."),
  ],
};

export function chapter4Lesson(id: string, lang: "bm" | "dlp") {
  const item = Object.values(chapter4Lessons).flat().find((item) => item.id === id);
  if (!item) throw new Error(`Missing Chapter 4 lesson: ${id}`);
  return { title: item.term[lang], body: item.statement[lang] };
}

export const scienceF3Chapter4Source: ScienceF3ChapterSource = {
  chapter: 4,
  title: bi("Kereaktifan Logam", "Reactivity of Metals"),
  mission: bi("Logam dalam telefon, bangunan dan kenderaan diperoleh daripada mineral dalam kerak Bumi.", "Metals in phones, buildings and vehicles are obtained from minerals in Earth's crust."),
  whyItMatters: bi("Siri kereaktifan membantu kita memilih kaedah pengekstrakan sambil mencari penyelesaian kepada kesan perlombongan.", "The reactivity series helps us choose extraction methods while finding solutions to mining impacts."),
  objectives: [bi("Kenal pasti mineral, unsur gabungan dan hubungan sifat dengan kegunaan.", "Identify minerals, constituent elements and property–use relationships."), bi("Gunakan bukti tindak balas dengan oksigen untuk menyusun logam serta menentukan kedudukan karbon dan hidrogen.", "Use oxygen-reaction evidence to arrange metals and locate carbon and hydrogen."), bi("Terangkan pengekstrakan ferum dan timah serta cadangkan penyelesaian kepada kesan perlombongan.", "Explain iron and tin extraction and suggest solutions to mining impacts.")],
  summary: bi("Mineral ialah unsur atau sebatian semula jadi. Bukti tindak balas menentukan siri kereaktifan, termasuk Al > C > Zn > H > Fe. Kereaktifan menentukan kaedah pengekstrakan; perlombongan perlu dirancang untuk mengurangkan kesannya.", "Minerals are natural elements or compounds. Reaction evidence determines the reactivity series, including Al > C > Zn > H > Fe. Reactivity determines extraction methods; mining must be planned to reduce its impacts."),
  subtopics: [
    { number: "4.1", title: bi("Kepelbagaian Mineral", "Variety of Minerals"), introduction: bi("Kenal pasti mineral melalui komposisi dan sifatnya, kemudian hubungkaitkan sifat dengan kegunaan.", "Identify minerals through their composition and properties, then relate properties to uses."), facts: chapter4Lessons.minerals },
    { number: "4.2", title: bi("Siri Kereaktifan Logam", "Reactivity Series of Metals"), introduction: bi("Bandingkan pemerhatian, tulis persamaan perkataan dan buat kesimpulan tentang kereaktifan.", "Compare observations, write word equations and infer relative reactivity."), facts: chapter4Lessons.reactivity },
    { number: "4.3", title: bi("Pengekstrakan Logam daripada Bijihnya", "Extraction of Metals from their Ores"), introduction: bi("Pilih kaedah mengikut kereaktifan, ikuti proses pengekstrakan dan cadangkan penyelesaian kepada kesan perlombongan.", "Choose methods by reactivity, follow extraction processes and propose solutions to mining impacts."), facts: chapter4Lessons.extraction },
  ],
};
