import type { ChapterContent } from "@/content/types";
import { scienceF3Chapters } from "./chapter-data";
import { buildScienceF3MindMap } from "./mindmap-builder";
import type { ScienceF3InteractiveContent } from "./interactive-types";
import { getScienceF3MasterQuizzes } from "./master-quizzes.generated";

import { scienceF3C1InteractiveBM } from "./chapter-1/interactive-bm";
import { scienceF3C1InteractiveDLP } from "./chapter-1/interactive-dlp";
import { scienceF3C2InteractiveBM } from "./chapter-2/interactive-bm";
import { scienceF3C2InteractiveDLP } from "./chapter-2/interactive-dlp";
import { scienceF3C3InteractiveBM } from "./chapter-3/interactive-bm";
import { scienceF3C3InteractiveDLP } from "./chapter-3/interactive-dlp";
import { scienceF3C4InteractiveBM } from "./chapter-4/interactive-bm";
import { scienceF3C4InteractiveDLP } from "./chapter-4/interactive-dlp";
import { scienceF3C5InteractiveBM } from "./chapter-5/interactive-bm";
import { scienceF3C5InteractiveDLP } from "./chapter-5/interactive-dlp";
import { scienceF3C6InteractiveBM } from "./chapter-6/interactive-bm";
import { scienceF3C6InteractiveDLP } from "./chapter-6/interactive-dlp";
import { projectF3Interactive } from "./project-bilingual";
import { scienceF3C7Interactive } from "./chapter-7/interactive";
import { scienceF3C8Interactive } from "./chapter-8/interactive";
import { scienceF3C9Interactive } from "./chapter-9/interactive";
import { scienceF3C10Interactive } from "./chapter-10/interactive";

import { scienceF3C1NotesBM } from "./chapter-1/notes-bm";
import { scienceF3C1NotesDLP } from "./chapter-1/notes-dlp";
import { scienceF3C1FlashcardsBM } from "./chapter-1/flashcards-bm";
import { scienceF3C1FlashcardsDLP } from "./chapter-1/flashcards-dlp";
import { scienceF3C2NotesBM } from "./chapter-2/notes-bm";
import { scienceF3C2NotesDLP } from "./chapter-2/notes-dlp";
import { scienceF3C2FlashcardsBM } from "./chapter-2/flashcards-bm";
import { scienceF3C2FlashcardsDLP } from "./chapter-2/flashcards-dlp";
import { scienceF3C3NotesBM } from "./chapter-3/notes-bm";
import { scienceF3C3NotesDLP } from "./chapter-3/notes-dlp";
import { scienceF3C3FlashcardsBM } from "./chapter-3/flashcards-bm";
import { scienceF3C3FlashcardsDLP } from "./chapter-3/flashcards-dlp";
import { scienceF3C4NotesBM } from "./chapter-4/notes-bm";
import { scienceF3C4NotesDLP } from "./chapter-4/notes-dlp";
import { scienceF3C4FlashcardsBM } from "./chapter-4/flashcards-bm";
import { scienceF3C4FlashcardsDLP } from "./chapter-4/flashcards-dlp";
import { scienceF3C5NotesBM } from "./chapter-5/notes-bm";
import { scienceF3C5NotesDLP } from "./chapter-5/notes-dlp";
import { scienceF3C5FlashcardsBM } from "./chapter-5/flashcards-bm";
import { scienceF3C5FlashcardsDLP } from "./chapter-5/flashcards-dlp";
import { scienceF3C6NotesBM } from "./chapter-6/notes-bm";
import { scienceF3C6NotesDLP } from "./chapter-6/notes-dlp";
import { scienceF3C6FlashcardsBM } from "./chapter-6/flashcards-bm";
import { scienceF3C6FlashcardsDLP } from "./chapter-6/flashcards-dlp";
import { scienceF3C7NotesBM } from "./chapter-7/notes-bm";
import { scienceF3C7NotesDLP } from "./chapter-7/notes-dlp";
import { scienceF3C7FlashcardsBM } from "./chapter-7/flashcards-bm";
import { scienceF3C7FlashcardsDLP } from "./chapter-7/flashcards-dlp";
import { scienceF3C8NotesBM } from "./chapter-8/notes-bm";
import { scienceF3C8NotesDLP } from "./chapter-8/notes-dlp";
import { scienceF3C8FlashcardsBM } from "./chapter-8/flashcards-bm";
import { scienceF3C8FlashcardsDLP } from "./chapter-8/flashcards-dlp";
import { scienceF3C9NotesBM } from "./chapter-9/notes-bm";
import { scienceF3C9NotesDLP } from "./chapter-9/notes-dlp";
import { scienceF3C9FlashcardsBM } from "./chapter-9/flashcards-bm";
import { scienceF3C9FlashcardsDLP } from "./chapter-9/flashcards-dlp";
import { scienceF3C10NotesBM } from "./chapter-10/notes-bm";
import { scienceF3C10NotesDLP } from "./chapter-10/notes-dlp";
import { scienceF3C10FlashcardsBM } from "./chapter-10/flashcards-bm";
import { scienceF3C10FlashcardsDLP } from "./chapter-10/flashcards-dlp";

const notes = [
  [scienceF3C1NotesBM, scienceF3C1NotesDLP],
  [scienceF3C2NotesBM, scienceF3C2NotesDLP],
  [scienceF3C3NotesBM, scienceF3C3NotesDLP],
  [scienceF3C4NotesBM, scienceF3C4NotesDLP],
  [scienceF3C5NotesBM, scienceF3C5NotesDLP],
  [scienceF3C6NotesBM, scienceF3C6NotesDLP],
  [scienceF3C7NotesBM, scienceF3C7NotesDLP],
  [scienceF3C8NotesBM, scienceF3C8NotesDLP],
  [scienceF3C9NotesBM, scienceF3C9NotesDLP],
  [scienceF3C10NotesBM, scienceF3C10NotesDLP],
] as const;

const quizzes = [
  [getScienceF3MasterQuizzes(1, "bm"), getScienceF3MasterQuizzes(1, "dlp")],
  [getScienceF3MasterQuizzes(2, "bm"), getScienceF3MasterQuizzes(2, "dlp")],
  [getScienceF3MasterQuizzes(3, "bm"), getScienceF3MasterQuizzes(3, "dlp")],
  [getScienceF3MasterQuizzes(4, "bm"), getScienceF3MasterQuizzes(4, "dlp")],
  [getScienceF3MasterQuizzes(5, "bm"), getScienceF3MasterQuizzes(5, "dlp")],
  [getScienceF3MasterQuizzes(6, "bm"), getScienceF3MasterQuizzes(6, "dlp")],
  [getScienceF3MasterQuizzes(7, "bm"), getScienceF3MasterQuizzes(7, "dlp")],
  [getScienceF3MasterQuizzes(8, "bm"), getScienceF3MasterQuizzes(8, "dlp")],
  [getScienceF3MasterQuizzes(9, "bm"), getScienceF3MasterQuizzes(9, "dlp")],
  [getScienceF3MasterQuizzes(10, "bm"), getScienceF3MasterQuizzes(10, "dlp")],
] as const;

const flashcards = [
  [scienceF3C1FlashcardsBM, scienceF3C1FlashcardsDLP],
  [scienceF3C2FlashcardsBM, scienceF3C2FlashcardsDLP],
  [scienceF3C3FlashcardsBM, scienceF3C3FlashcardsDLP],
  [scienceF3C4FlashcardsBM, scienceF3C4FlashcardsDLP],
  [scienceF3C5FlashcardsBM, scienceF3C5FlashcardsDLP],
  [scienceF3C6FlashcardsBM, scienceF3C6FlashcardsDLP],
  [scienceF3C7FlashcardsBM, scienceF3C7FlashcardsDLP],
  [scienceF3C8FlashcardsBM, scienceF3C8FlashcardsDLP],
  [scienceF3C9FlashcardsBM, scienceF3C9FlashcardsDLP],
  [scienceF3C10FlashcardsBM, scienceF3C10FlashcardsDLP],
] as const;

const interactive: Partial<
  Record<number, readonly [ScienceF3InteractiveContent, ScienceF3InteractiveContent]>
> = {
  1: [scienceF3C1InteractiveBM, scienceF3C1InteractiveDLP],
  2: [scienceF3C2InteractiveBM, scienceF3C2InteractiveDLP],
  3: [scienceF3C3InteractiveBM, scienceF3C3InteractiveDLP],
  4: [scienceF3C4InteractiveBM, scienceF3C4InteractiveDLP],
  5: [scienceF3C5InteractiveBM, scienceF3C5InteractiveDLP],
  6: [scienceF3C6InteractiveBM, scienceF3C6InteractiveDLP],
  7: [
    projectF3Interactive(scienceF3C7Interactive, "bm"),
    projectF3Interactive(scienceF3C7Interactive, "dlp"),
  ],
  8: [
    projectF3Interactive(scienceF3C8Interactive, "bm"),
    projectF3Interactive(scienceF3C8Interactive, "dlp"),
  ],
  9: [
    projectF3Interactive(scienceF3C9Interactive, "bm"),
    projectF3Interactive(scienceF3C9Interactive, "dlp"),
  ],
  10: [
    projectF3Interactive(scienceF3C10Interactive, "bm"),
    projectF3Interactive(scienceF3C10Interactive, "dlp"),
  ],
};

export const scienceF3ChapterContent: ChapterContent[] = scienceF3Chapters.flatMap(
  (chapter, index) =>
    (["bm", "dlp"] as const).map((lang, langIndex) => ({
      id: `science-f3-c${chapter.chapter}-${lang}`,
      subjectId: "science",
      form: "Form 3",
      chapterKey: `Chapter ${chapter.chapter}`,
      title: chapter.title[lang],
      lang,
      mindMap: {
        data: buildScienceF3MindMap(chapter.chapter, lang),
        title: chapter.title[lang],
      },
      notes: notes[index][langIndex],
      quiz: quizzes[index][langIndex],
      flashcards: flashcards[index][langIndex],
      ...(interactive[chapter.chapter]
        ? { sciF3InteractiveData: interactive[chapter.chapter]![langIndex] }
        : {}),
    })),
);
